Before playing edit the level.txt file so that BEARWOOD is at the top of the list.

If you do not have NFK installed in the default directory then move all files into a folder named trench in your levels directory.